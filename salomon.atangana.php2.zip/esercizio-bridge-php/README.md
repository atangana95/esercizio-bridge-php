# esercizio-bridge-php
	l'esercizio in sostanza è un sito di espozizione delle frutte e dei fiori.
Il primo file che viene eseguito è il file Login.php dove l'utente si identifica per accedere al sito. Una volta fatta l'accesso, viene indirizzato nel file index.php dove trova dei link ad altri file come Fiori.php , Frutta.php etc... in base agli interissi. Da questo file l'utente ha la possibilità di vedere i prodotti disponibili nei rispettivi file di frutta e di fiori, da li puo anche comprare se vuole aggiungendo le cose a un carello messo a disposizione per gli aquisti. Dal file index , l'utente puo aggiungere un nuovo prodotto che vuole vendere indirizzandosi sul file aggiungiProdottiVendita.php e fine quando ha terminato puo chiudere la sessione faccendo un logout.


partecipanti : 
-ATANGANA OSSONO
-JACOPO COLOZZI

